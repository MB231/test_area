use "make clean && make && ./build/test"
